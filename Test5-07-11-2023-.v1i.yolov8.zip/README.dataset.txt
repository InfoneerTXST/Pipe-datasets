# Test5(07/11/2023) > 2023-07-13 10:43am
https://universe.roboflow.com/texas-state/test5-07-11-2023

Provided by a Roboflow user
License: CC BY 4.0

