# Test3(07/05/2023) > 2023-07-07 12:51pm
https://universe.roboflow.com/texas-state/test3-07-05-2023

Provided by a Roboflow user
License: CC BY 4.0

