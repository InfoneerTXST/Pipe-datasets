# Test1(06/30/2023) > 2023-07-04 11:55am
https://universe.roboflow.com/texas-state/test1-06-30-2023

Provided by a Roboflow user
License: CC BY 4.0

