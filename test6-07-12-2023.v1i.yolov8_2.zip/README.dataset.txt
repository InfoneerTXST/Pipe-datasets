# test6-07-12-2023 > 2023-07-14 2:26pm
https://universe.roboflow.com/texas-state/test6-07-12-2023

Provided by a Roboflow user
License: CC BY 4.0

