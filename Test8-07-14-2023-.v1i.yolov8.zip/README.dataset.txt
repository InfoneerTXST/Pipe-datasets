# Test8(07/14/2023) > 2023-07-16 10:48am
https://universe.roboflow.com/texas-state/test8-07-14-2023

Provided by a Roboflow user
License: CC BY 4.0

