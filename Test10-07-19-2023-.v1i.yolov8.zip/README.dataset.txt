# Test10(07/19/2023) > 2023-07-24 11:34am
https://universe.roboflow.com/texas-state/test10-07-19-2023

Provided by a Roboflow user
License: CC BY 4.0

