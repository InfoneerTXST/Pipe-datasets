# Test4(07/07/2023) > 2023-07-10 12:46pm
https://universe.roboflow.com/texas-state/test4-07-07-2023

Provided by a Roboflow user
License: CC BY 4.0

