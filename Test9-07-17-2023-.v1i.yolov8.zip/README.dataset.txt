# Test9(07/17/2023) > 2023-07-20 2:37pm
https://universe.roboflow.com/texas-state/test9-07-17-2023

Provided by a Roboflow user
License: CC BY 4.0

